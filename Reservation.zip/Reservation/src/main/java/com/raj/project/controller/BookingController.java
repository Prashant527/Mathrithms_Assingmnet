package com.raj.project.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.raj.project.model.Ticket;
import com.raj.project.service.SequenceGeneratorService;
import com.raj.project.service.TicketService;

@RestController
public class BookingController {
	

	@Autowired
	TicketService ticketService;
	
	@Autowired
	private SequenceGeneratorService service;
	
	@CrossOrigin("http://localhost:4200")
	@RequestMapping( value="/ticket",method=RequestMethod.POST)
	public Ticket saveTicket(@RequestBody Ticket ticket)
	{
		ticket.setTicketId(service.getSequenceNumber(Ticket.SEQUENCE_NAME));
		return ticketService.saveTicket(ticket);
		
	}
	
	@CrossOrigin("http://localhost:4200")
	@RequestMapping(value="/alltickets",method =RequestMethod.GET )
	public List<Ticket> getallTickets()
	{
		return ticketService.getallTickets();	
	}
	
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/ticket/{ticketId}")
	public Optional<Ticket> getTicketById(@PathVariable int ticketId){
		return ticketService.findTicketById(ticketId);	
	}
	
	@GetMapping("/user/{userId}")
	public Optional<Ticket> getTicketByUserId(@PathVariable int userId){
		return ticketService.findByUserId(userId);
	}
	
	@CrossOrigin("http://localhost:4200")
	@DeleteMapping("/delete/{ticketId}")
	public String deleteTicketById(@PathVariable int ticketId){
		ticketService.deleteTicketById(ticketId);	
		return "Ticket With ID:" +ticketId+" got Deleted.";
	}
	

}
