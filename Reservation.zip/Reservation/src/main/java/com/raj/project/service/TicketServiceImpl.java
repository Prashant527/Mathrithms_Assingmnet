package com.raj.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.raj.project.model.Ticket;

@Repository
@Service
public class TicketServiceImpl implements TicketService{
	
	@Autowired
	MongoTemplate mongoTemplate;
	final String COLLECTION="Tickets";
	
	@Autowired
	TicketRepo ticketRepo;

	@Override
	public Ticket saveTicket(Ticket ticket) {
		return mongoTemplate.save(ticket);
	}

	@Override
	public List<Ticket> getallTickets() {
		return mongoTemplate.findAll(Ticket.class);
	}

	@Override
	public Optional<Ticket> findTicketById(int ticketId) {
		return ticketRepo.findById(ticketId);
	}

	
	@Override
	public Optional<Ticket> findByUserId(int userId) {
		return ticketRepo.findById(userId);
	}

	@Override
	public void deleteTicketById(int ticketId) {
			ticketRepo.deleteById(ticketId);
	}

	


}
