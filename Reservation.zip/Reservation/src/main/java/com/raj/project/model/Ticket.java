package com.raj.project.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.ToString;

@ToString
@Document(collection="Tickets")
public class Ticket {
	
	@Transient
	public static final String SEQUENCE_NAME="ticket_sequence";
	
	@Id
	private int ticketId;
	private int userId;
	
	public Ticket() {
		
	}
	
	public Ticket(int ticketId, int userId) {
		super();
		this.ticketId = ticketId;
		this.userId = userId;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	

}
