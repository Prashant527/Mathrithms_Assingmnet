import { Component, OnInit } from '@angular/core';
import { Train } from '../train';
import { TrainDetailsService } from '../train-details.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-train-details',
  templateUrl: './train-details.component.html',
  styleUrls: ['./train-details.component.css']
})
export class TrainDetailsComponent implements OnInit {

  trainNo:any;
  train: any;

  constructor(private route: ActivatedRoute,private router: Router,
    private service:TrainDetailsService) { }

  ngOnInit() {
    this.train=new Train(0,"","","","","");
    this.trainNo =this.route.snapshot.params['trainNo'];

    this.service.getTrain(this.trainNo).subscribe(data=>{
      console.log(data)
      this.train=data;
    },error => console.log(error));
  }

  list(){
    this.router.navigate(['train-list']);
  }

}
