import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserRegistrationService } from '../user-registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: User=new User(0,"","",0,"");
  message:any;

  constructor(private service:UserRegistrationService,private router:Router) { }

  ngOnInit(): void {
  }

  public registerNow(){
    let responce=this.service.doRegisteration(this.user);
    responce.subscribe((data)=>this.message=data);
    this.router.navigate(['user']);

  }

}
