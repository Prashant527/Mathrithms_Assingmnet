import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { User } from '../user';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  user=new User(0,"","",0,"");
  opened: false | true |undefined;


  constructor(private router: Router,
    private service: UserRegistrationService) { }

  ngOnInit() {
  }

  loginUser(){
    this.service.doLogin(this.user).subscribe(
      data=>console.log("responce got"),
      error=>console.log("exception occured")
    )
    if(this.user.email=="admin@gmail.com" && this.user.password=="admin"){
      this.router.navigate(['admin']);
    }else{
      this.router.navigate(['user']);
    }
     
  }


}
