import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { BookingComponent } from './booking/booking.component';
import { CancleComponent } from './cancle/cancle.component';
import {UserRegistrationService} from './user-registration.service';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TrainListComponent } from './train-list/train-list.component';
import { AddTrainComponent } from './add-train/add-train.component';
import { TrainDetailsService } from './train-details.service';
import { AuthenticationService } from './authentication.service';
import { TrainDetailsComponent } from './train-details/train-details.component';
import { UserComponent } from './user/user.component';
import { UserTrainsComponent } from './user-trains/user-trains.component';
import { UpdateTrainComponent } from './update-train/update-train.component';
import { HeaderComponent } from './header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatCardModule} from '@angular/material/card';
import {MatTableModule} from '@angular/material/table';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatTabsModule} from '@angular/material/tabs';




@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    LoginComponent,
    RegisterComponent,
    BookingComponent,
    CancleComponent,
    TrainListComponent,
    AddTrainComponent,
    TrainDetailsComponent,
    UserComponent,
    UserTrainsComponent,
    UpdateTrainComponent,
    HeaderComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,MatButtonModule,MatIconModule,
    MatCardModule,MatTableModule,MatFormFieldModule,MatCheckboxModule,
    MatSidenavModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,MatTabsModule
   
  ],
  providers: [UserRegistrationService,TrainDetailsService,AuthenticationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
