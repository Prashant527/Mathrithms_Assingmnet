import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Ticket} from '../ticket';
import { TicketService } from '../ticket.service';

@Component({
  selector: 'app-cancle',
  templateUrl: './cancle.component.html',
  styleUrls: ['./cancle.component.css']
})
export class CancleComponent implements OnInit {

  ticket:Ticket=new Ticket(0,0,"","","","","","",0,0,"",true);
  

  constructor(private router: Router,private service:TicketService) { }

  ngOnInit(): void {
  }

  cancleNow(ticketNo:number){
    this.service.cancleTicket(ticketNo).subscribe();
    this.router.navigate(['header']);
  }

}
