import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTrainComponent } from './add-train/add-train.component';
import { AdminComponent } from './admin/admin.component';
import { BookingComponent } from './booking/booking.component';
import { CancleComponent } from './cancle/cancle.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { TrainDetailsComponent } from './train-details/train-details.component';
import { TrainListComponent } from './train-list/train-list.component';
import { UpdateTrainComponent } from './update-train/update-train.component';
import { UserTrainsComponent } from './user-trains/user-trains.component';
import { UserComponent } from './user/user.component';


const routes: Routes = [
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'admin',component:AdminComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'booking',component:BookingComponent},
  {path:'cancle',component:CancleComponent},
  {path:'train-list',component:TrainListComponent},
  {path:'update-train',component:UpdateTrainComponent},
  {path:'admin/train-list',component:TrainListComponent},
  {path:'header',component:HeaderComponent},
  {path:'admin/train-list',component:TrainListComponent},
  {path:'admin/add-train',component:AddTrainComponent},
  {path:'train-list/train-details/:trainNo',component:TrainDetailsComponent},
  {path:'admin/train-details/:trainNo',component:TrainDetailsComponent},
  {path:'train-list/update-train/:trainNo',component:UpdateTrainComponent},
  {path:'user',component:UserComponent},
  {path:'user-trains',component:UserTrainsComponent},
  {path:'user-trains/train-details/:trainNo',component:TrainDetailsComponent},
  {path:'user/user-trains',component:UserTrainsComponent},
  {path:'register/user',component:UserComponent}
  
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
