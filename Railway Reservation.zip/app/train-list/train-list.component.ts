import { Component, OnInit } from '@angular/core';
import { Train } from '../train';
import { TrainDetailsService } from '../train-details.service';
import {Observable} from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-train-list',
  templateUrl: './train-list.component.html',
  styleUrls: ['./train-list.component.css']
})
export class TrainListComponent implements OnInit {

  trains:any;
  trainNo:any;

  constructor(private trainService: TrainDetailsService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.trains = this.trainService.getTrainList();
  }

  deleteTrain(trainNo: number) {
    this.trainService.deleteTrain(trainNo)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  // trainDetails(trainNo: number){
  //   this.trainService.getTrain(trainNo).subscribe(
  //     data=>{
  //       console.log(data);
  //       this.reloadData();
  //     }
  //   )
  // }
  trainDetails(trainNo:number){
    this.router.navigate(['admin/train-details',trainNo]);
  }

  updateTrain(trainNo: number){
    this.router.navigate(['train-list/update-train',trainNo]);
  }

  findTrain(trainNo:number){
    this.trainService.getTrain(trainNo).subscribe();
    this.router.navigate(['admin/train-details',trainNo]);
  }
  trainBooking(train:Train){
    this.router.navigate(['booking']);

  }
  

  





}

