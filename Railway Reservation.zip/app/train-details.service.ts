import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TrainDetailsService {

  //private baseUrl="http://localhost:8085/";
  private baseUrl="Onlinerailwayreservationsystem-env.eba-jemmvf72.ap-south-1.elasticbeanstalk.com ";
  

  constructor(private http:HttpClient) { }

  getTrain(trainNo:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/${trainNo}`);
  }
  
  addTrain(train: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl+"/add"}`, train);
  }

  updateTrain(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl+"/update"}/${id}`, value);
  }

  deleteTrain(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getTrainList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/find`);
  }
}
