import { Component, OnInit } from '@angular/core';
import { TrainDetailsService } from '../train-details.service';
import { ActivatedRoute, Router } from '@angular/router';
import {Train} from '../train';

@Component({
  selector: 'app-update-train',
  templateUrl: './update-train.component.html',
  styleUrls: ['./update-train.component.css']
})
export class UpdateTrainComponent implements OnInit {

  trainNo: any;
  train: Train = new Train(0,"","","","","");

  constructor(private route: ActivatedRoute,private router: Router,
    private service: TrainDetailsService) { }

  ngOnInit() {
    this.train= new Train(0,"","","","","");

    this.trainNo = this.route.snapshot.params['trainNo'];
    
    this.service.getTrain(this.trainNo)
      .subscribe(data => {
        console.log(data)
        this.train = data;
      }, error => console.log(error));
  }

  updateTrain() {
    this.service.updateTrain(this.trainNo, this.train)
      .subscribe(data => {
        console.log(data);
        this.train = new Train(0,"","","","","");
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateTrain();    
  }

  gotoList() {
    this.router.navigate(['admin/train-list']);
  }

}
