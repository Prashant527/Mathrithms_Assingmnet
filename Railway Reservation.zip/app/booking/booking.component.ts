import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ticket } from '../ticket';
import { TicketService } from '../ticket.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  ticket:Ticket=new Ticket(0,0,"","","","","","",0,0,"",true);
  msg:any;
  ticketNo:any;
  

  constructor(private service:TicketService,private router: Router,) { }

  ngOnInit(): void {
  }

  bookNow(){
    let resp=this.service.bookTicket(this.ticket);
    resp.subscribe();
    this.msg="Booking Successful !";
  }
  showTicket(){
    this.ticketNo=this.service.getTicket(this.ticketNo).subscribe();
  }

}
