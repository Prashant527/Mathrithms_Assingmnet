export class Ticket{
    ticketNo:number;
    trainNo:number;
    bookingType:string;
    seatType:string;
    sourceStation:string;
    destinationStation:string;
    userName:string;
    userEmail:string;
    mobile:number;
    numberOfSeats:number;
    dateOfJourney:string;
    isActive:boolean;


    constructor(ticketNo:number,
        trainNo:number,
        bookingType:string,
        seatType:string,
        sourceStation:string,
        destinationStation:string,
        userName:string,
        userEmail:string,
        mobile:number,
        numberOfSeats:number,
        dateOfJourney:string,isActive:boolean){
            this.ticketNo=ticketNo;
            this.trainNo=trainNo;
            this.bookingType=bookingType;
            this.seatType=seatType;
            this.sourceStation=sourceStation;
            this.destinationStation=destinationStation;
            this.userName=userName;
            this.userEmail=userEmail;
            this.mobile=mobile;
            this.numberOfSeats=numberOfSeats;
            this.dateOfJourney=dateOfJourney;
            this.isActive=isActive;
        }


}