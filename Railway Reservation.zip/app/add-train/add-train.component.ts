import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { from } from 'rxjs';
import { TrainDetailsService } from '../train-details.service';
import {Train} from '../train'


@Component({
  selector: 'app-add-train',
  templateUrl: './add-train.component.html',
  styleUrls: ['./add-train.component.css']
})
export class AddTrainComponent implements OnInit {

  train: Train = new Train(0,"","","","","");
  submitted=false;

  constructor(private trainService: TrainDetailsService,
    private router:Router) { }

  ngOnInit(): void {

  }
  newTrain():void{
    this.submitted=false;
    this.train=new Train(0,"","","","","");
  }

  save() {
    this.trainService
    .addTrain(this.train).subscribe(data => {
      console.log(data)
      this.train = new Train(0,"","","","","");
      this.gotoList();
    }, 
    error => console.log(error));
  }
  onSubmit() {
    this.submitted = true;
    this.save();    
  }
  gotoList() {
    this.router.navigate(['admin/train-list']);
  }

}
