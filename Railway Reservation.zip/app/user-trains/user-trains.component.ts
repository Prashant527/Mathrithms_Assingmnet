import { Component, OnInit } from '@angular/core';
import { Train } from '../train';
import { TrainDetailsService } from '../train-details.service';
import {Observable} from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-trains',
  templateUrl: './user-trains.component.html',
  styleUrls: ['./user-trains.component.css']
})
export class UserTrainsComponent implements OnInit {

  trains:any;
  trainName:any;

  constructor(private trainService: TrainDetailsService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.trains = this.trainService.getTrainList();
  }

  deleteTrain(trainNo: number) {
    this.trainService.deleteTrain(trainNo)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  // trainDetails(trainNo: number){
  //   this.trainService.getTrain(trainNo).subscribe(
  //     data=>{
  //       console.log(data);
  //       this.reloadData();
  //     }
  //   )
  // }
  trainDetails(trainNo:number){
    this.router.navigate(['user-trains/train-details',trainNo]);
  }


  findTrain(trainNo:number){
    this.trainService.getTrain(trainNo).subscribe();
  }
  trainBooking(train:Train){
    this.router.navigate(['booking']);

  }

}
