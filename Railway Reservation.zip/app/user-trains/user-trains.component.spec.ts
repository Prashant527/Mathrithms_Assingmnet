import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTrainsComponent } from './user-trains.component';

describe('UserTrainsComponent', () => {
  let component: UserTrainsComponent;
  let fixture: ComponentFixture<UserTrainsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserTrainsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTrainsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
