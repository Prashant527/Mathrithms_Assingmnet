import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TicketService {

  private baseUrl="http://localhost:8090";

  constructor(private http:HttpClient) { }

  public bookTicket(ticket:any){
    return this.http.post("http://localhost:8090/ticket",ticket,{responseType: 'text' as 'json'});
  }

  public cancleTicket(ticketNo:number): Observable<any> {
    return this.http.delete(`${this.baseUrl+"/delete"}/${ticketNo}`);
  }
  public getTicket(ticketNo:number):Observable<any>{
    return this.http.get(`${this.baseUrl+"/ticket"}/${ticketNo}`);
  }
  public getAllTickets():Observable<any>{
    return this.http.get("http://localhost:8090/alltickets");
  }


}
