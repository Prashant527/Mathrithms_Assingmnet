import { Time } from "@angular/common";

export class Train {
  trainNo:number;
  trainName:string;
  sourceStation: string;
  destinationStation: string;
  sourceTime: string;
  destinationTime: string;

  constructor(
        trainNo:number,
        trainName: string,
        sourceStation: string,
        destinationStation: string,
        sourceTime: string,
        destinationTime: string
        ){
          this.trainNo=trainNo;
          this.trainName=trainName;
          this.sourceStation=sourceStation;
          this.destinationStation=destinationStation;
          this.sourceTime=sourceTime;
          this.destinationTime=destinationTime;

        }

   

}