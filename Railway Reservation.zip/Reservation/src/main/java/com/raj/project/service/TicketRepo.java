package com.raj.project.service;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.raj.project.model.Ticket;

public interface TicketRepo extends MongoRepository<Ticket,Integer>{

	

}
