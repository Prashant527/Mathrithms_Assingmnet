package com.raj.project.service;

import java.util.List;
import java.util.Optional;

import com.raj.project.model.Ticket;

public interface TicketService {

	public Ticket saveTicket(Ticket ticket);

	public List<Ticket> getallTickets();

	public Optional<Ticket> findByUserId(int userId);

	public Optional<Ticket> findTicketById(int ticketId);

	public void deleteTicketById(int ticketId);

	



}
