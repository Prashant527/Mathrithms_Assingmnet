package com.raj.project;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.raj.project.model.TrainDetails;
import com.raj.project.service.AdminService;

@SpringBootTest
class TrainScheduleApplicationTests {
	
	@Autowired
	private AdminService adminServices;
	
	
	@MockBean
	MongoTemplate mongoTemplate;
	
	

	@Test
	public void findAllTest() {
		
		List<TrainDetails> trainlist = new ArrayList<>();
		TrainDetails train1= new TrainDetails(10245,"Patna Express","Patan","Delhi","5-45-55","22-14-30");
		TrainDetails train2= new TrainDetails(10246,"Kota Express","Kota","Delhi","15-45-55","2-14-30");
		trainlist.add(train1);
		trainlist.add(train2);
		
		List<TrainDetails> list= (List<TrainDetails>) mongoTemplate.findAll(TrainDetails.class);
		assertEquals("Patna Express",list.get(1).getTrainName());
	
//		Mockito.when(adminServices.findAll()).thenReturn(trainlist);
//		assertThat(adminServices.findAll()).isEqualTo(trainlist);
		
//		List<TrainDetails> list= adminServices.findAll();
//		assertEquals(2, list.size());
//		verify(adminServices,times(1)).findAll();
	}
	@Test
	public void addTrainTest() {
		TrainDetails newTrain=new TrainDetails();
		newTrain.setTrainNo(10222);
		newTrain.setTrainName("Punjab Special");
		newTrain.setSourceStation("Amritsar");
		newTrain.setDestinationStation("Pune");
		newTrain.setArrival("12-45-12");
		newTrain.setDeparture("11-30-30");
		
		Mockito.when(mongoTemplate.save(newTrain)).thenReturn(newTrain);
		assertThat(adminServices.addTrain(newTrain)).isEqualTo(newTrain);
	}
	
	@Test
	public void deleteTest() {
		TrainDetails newTrain=new TrainDetails();
		newTrain.setTrainNo(10222);
		newTrain.setTrainName("Punjab Special");
		newTrain.setSourceStation("Amritsar");
		newTrain.setDestinationStation("Pune");
		newTrain.setArrival("12-45-12");
		newTrain.setDeparture("11-30-30");
		
		
	}

}
