package com.raj.project.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.raj.project.controller.AdminController;
import com.raj.project.model.TrainDetails;
import com.raj.project.service.AdminService;

@RunWith(SpringRunner.class)
@WebMvcTest(value=AdminController.class)
@SpringBootTest
public class AdminControllerTest {
	
	@Autowired
	private MockMvc mvc;
	
	@MockBean
	private AdminService adminService;
	
	@Test
	public void showTraindetails() throws Exception{
		TrainDetails train1=new TrainDetails();
		train1.setTrainNo(12345);
		train1.setTrainName("Gujrat Express");
		train1.setSourceStation("Gujrat");
		train1.setDestinationStation("Delhi");
		train1.setArrival("1:20:45");
		train1.setDeparture("22:20:44");
		
		String inputInJson = this.mapToJson(train1);
		String URI="/find";
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post(URI)
				.accept(MediaType.APPLICATION_JSON).content(inputInJson)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		String outputInJson = response.getContentAsString();
		
		assertThat(outputInJson).isEqualTo(inputInJson);
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		
		
	}
	
	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}

}
