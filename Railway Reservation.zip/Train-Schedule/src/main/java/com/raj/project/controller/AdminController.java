package com.raj.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.raj.project.exception.ResourceNotFoundException;
import com.raj.project.model.TrainDetails;
import com.raj.project.service.AdminService;
import com.raj.project.service.TrainService;

@RestController
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@Autowired
	public TrainService trainService;
	

	@RequestMapping(value="/find",method = RequestMethod.GET)
	public @ResponseBody List<TrainDetails> showTrainsDetails(){
		return adminService.findAll();
	}
	@GetMapping("/find/{trainNo}")
	public TrainDetails showTrainById(@PathVariable int trainNo){
		return trainService.findById(trainNo)
				.orElseThrow(()->new ResourceNotFoundException("Please Enter The correct Train Number."));
	}
	
	@RequestMapping(value="/add",method = RequestMethod.POST)
	public Map<String,Object> addTrains(@RequestBody TrainDetails train) {
		Map<String,Object> result =new HashMap<>();
		adminService.addTrain(train);
		result.put("message", "Train Added Successfully");
		result.put("TrainDetail", train);
		return result;	
	}

	@RequestMapping(value="/update/{id}",method = RequestMethod.PUT)
	public TrainDetails updateTrain(@RequestBody TrainDetails train,@PathVariable ("id") int trainNo){
		Optional<TrainDetails> existingTrain= trainService.findById(trainNo);
		existingTrain.orElseThrow(()->new ResourceNotFoundException("Please Enter The correct Train Number to Update."));
		return adminService.updateTrain(train);
		
	}
	
	@DeleteMapping("/delete")
	public String deleteAll() {
		trainService.deleteAll();
		return "All Train Details got Deleted.";
	}
	
	@DeleteMapping("delete/{trainNo}")
	public String deleteTrain(@PathVariable int trainNo) {
		Optional<TrainDetails> existingTrain= trainService.findById(trainNo);
		existingTrain.orElseThrow(()->new ResourceNotFoundException("Please Enter The correct Train Number to Update."));
		trainService.deleteById(trainNo) ;
		return "Train With ID: "+trainNo+" got Deleted. ";
	}
	

}
