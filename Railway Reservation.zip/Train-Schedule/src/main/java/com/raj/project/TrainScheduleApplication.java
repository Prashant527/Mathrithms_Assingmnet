package com.raj.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
@EnableEurekaClient
@SpringBootApplication
public class TrainScheduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainScheduleApplication.class, args);
	}

}
