package com.raj.project.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.raj.project.model.TrainDetails;
import com.raj.project.service.TrainService;

@RestController
public class TrainController {
	@Autowired
	public TrainService trainService;
	

	@GetMapping("/show")
	public List<TrainDetails> showTrainsDetails(){
		return trainService.findAll();
	}
	@GetMapping("/show/{trainNo}")
	public Optional<TrainDetails> showTrainById(@PathVariable int trainNo){
		return trainService.findById(trainNo);
	}
	
	
	

	
	
	

	
}
