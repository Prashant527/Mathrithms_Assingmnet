package com.raj.project.service;

import java.util.List;

import com.raj.project.model.TrainDetails;

public interface AdminService{
	
	public TrainDetails addTrain(TrainDetails train);
	
	public TrainDetails updateTrain(TrainDetails train); 

	
	public List<TrainDetails> findAll();

	public void delete();

	public void deleteById(int trainNo);

	

	


}
