package com.raj.project.service;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.raj.project.model.TrainDetails;

public interface TrainService extends MongoRepository<TrainDetails, Integer> {

	


}
