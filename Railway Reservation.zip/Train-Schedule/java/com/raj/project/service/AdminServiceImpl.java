package com.raj.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.raj.project.model.TrainDetails;

@Repository
@Service
public class AdminServiceImpl implements AdminService {
	
	
	@Autowired
	MongoTemplate mongoTemplate;
	final String COLLECTION="Trains";

	public TrainDetails addTrain(TrainDetails train) {
		return mongoTemplate.insert(train);	
	}

	@Override
	public TrainDetails updateTrain(TrainDetails train) {
		return mongoTemplate.save(train);	
	}

	public List<TrainDetails> findAll() {
		return mongoTemplate.findAll(TrainDetails.class);
	}

	@Override
	public void delete() {
		mongoTemplate.remove(TrainDetails.class);
		
	}

	@Override
	public void deleteById(int trainNo) {
		mongoTemplate.remove(trainNo);
		
	}

	



	


}
