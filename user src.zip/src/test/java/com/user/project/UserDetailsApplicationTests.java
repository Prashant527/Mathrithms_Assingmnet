package com.user.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.user.project.model.UserDetails;
import com.user.project.repository.UserRepository;
import com.user.project.repository.UserService;
@RunWith(SpringRunner.class)
@SpringBootTest
class UserDetailsApplicationTests {
	
//	@Autowired
//	private UserService userservice;
//	
//	@Autowired
//	private UserRepository userRepository;
//	
//	@Test
//	public void findTest() {
//		List<UserDetails> userlist=new ArrayList<>();
//		UserDetails user1=new UserDetails(4,"raman","7896541296","raman@gmail.com","78raman",null);
//		UserDetails user2=new UserDetails(5,"rohit","9896241236","rohit@gmail.com","asdfg",null);
//		UserDetails user3=new UserDetails(6,"ganesh","8816741244","ganesh@gmail.com","qwert",null);
//		userlist.add(user1);
//		userlist.add(user2);
//		userlist.add(user3);
//		when(userservice.find(user1)).thenReturn(user1);
//		when(userservice.find(user2)).thenReturn(user2);
//		when(userservice.find(user3)).thenReturn(user3);
//			
//		assertEquals(3, userlist.size());
//		verify(userservice,times(1)).find(user1);
//		
//		}
//	
//	@Test
//	public void createTest() {
//		UserDetails user=new UserDetails(6,"ganesh","8816741244","ganesh@gmail.com","qwert",null);
//		when(userRepository.save(user)).thenReturn(user);
//		assertEquals(user, userservice.create(user));
//	}
	
	

}
