package com.user.project.resource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.user.project.exception.ResourceNotFoundException;
import com.user.project.model.UserDetails;
import com.user.project.repository.UserRepository;
import com.user.project.repository.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	public UserRepository userRepository;
	
	@Autowired
	public UserService userService;
	
	@CrossOrigin("http://localhost:4200")
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public Map<String,Object> getlogin(@RequestBody UserDetails user){
		Map<String,Object> result=new HashMap<>();
	System.out.println("Logging in :" + user.getEmail());
    UserDetails user1=userService.find(user);
    
    if(user1!=null &&user1.getPassword().equals(user.getPassword()))
    {
    	result.put("msg", "Login Successful!");
    	result.put("user", user1);
    	result.put("loggedin", true);
    }
    else if(user.getEmail().equals("admin@gmail.com") && user.getPassword().equals("admin"))
    {
    	result.put("msg", "Login Successful!");
    	user.setName("ADMIN");
    	result.put("user", user);
    	result.put("loggedin", true);
    }
    else
    {
    	result.put("message", "Incorrect email/password.");
    	result.put("loggedin", false);
    }
    return result;
	}
	
	@CrossOrigin("http://localhost:4200")
	@RequestMapping(value="/register",method = RequestMethod.POST)
	public Map<String,Object> getUser(@RequestBody UserDetails user) {
		Map<String,Object> result=new HashMap<>();
		UserDetails user1=userService.find(user);
		if(user1!=null) {
			result.put("msg", "User is Already Registed.Please Login!");
		}
		else {
			userService.create(user);
			result.put("msg", "You are Registered successfully");
		}
	
		return result;
		
	}
	
	@GetMapping("/show")
	public List<UserDetails> showUser(){
		return userRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public UserDetails getUserById(@PathVariable (value = "id") int userId) {
		return this.userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
	}
	
	@PutMapping("update/{id}")
	public UserDetails updateUser(@RequestBody UserDetails user, @PathVariable ("id") int userId) {
		 UserDetails existingUser = userRepository.findById(userId)
			.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
		 existingUser.setName(user.getName());
		 existingUser.setMobile(user.getMobile());
		 existingUser.setEmail(user.getEmail());;
		 return userRepository.save(existingUser);
	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<UserDetails> deleteUser(@PathVariable ("id") int userId){
		 UserDetails existingUser = userRepository.findById(userId)
					.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
		 userRepository.delete(existingUser);
		 return ResponseEntity.ok().build();
	}
}
	