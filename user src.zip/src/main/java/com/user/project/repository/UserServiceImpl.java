package com.user.project.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.user.project.model.UserDetails;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	final String COLLECTION="User";

	@Override
	public UserDetails find(UserDetails user) {
		Query query=new Query(Criteria.where("email").is(user.getEmail()));
		return mongoTemplate.findOne(query, UserDetails.class,COLLECTION);
		
	}

	@Override
	public UserDetails create(UserDetails user) {
		return mongoTemplate.insert(user);
		
	}

}
