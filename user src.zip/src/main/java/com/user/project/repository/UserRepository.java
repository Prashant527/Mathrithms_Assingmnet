package com.user.project.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.user.project.model.UserDetails;

public interface UserRepository extends MongoRepository<UserDetails, Integer> {

	

}
