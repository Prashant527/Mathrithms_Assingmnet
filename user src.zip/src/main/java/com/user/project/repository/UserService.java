package com.user.project.repository;

import com.user.project.model.UserDetails;

public interface UserService {

	public UserDetails find(UserDetails user);

	public UserDetails create(UserDetails user);

}
